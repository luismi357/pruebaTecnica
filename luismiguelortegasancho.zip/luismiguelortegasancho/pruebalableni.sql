-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-07-2024 a las 00:29:46
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pruebalableni`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `fecha_registro`) VALUES
(1, 'luismiguel', '$2y$10$2BZdapGhcpYQl/moeAohZe5Mj8mP0V1ze0Jeti5VsYn7AlWInbKAa', '2024-06-27 08:25:21'),
(2, 'perico', '$2y$10$PzIR6fq7Aw0sickUdme4Pe2EPTdHxEubLLSyxYge/ljB2bQd8fb66', '2024-06-28 11:02:57'),
(3, 'admintessq', '$2y$10$JQIBR4CWAQKhVjfO2RKtruunr6QR1MVk.7yCT4FodMLupi6Bqwo7y', '2024-06-28 11:34:01'),
(4, 'luismiguel2', '$2y$10$BKjUgqdsowXQNQE1ED5dr.GlgEjR3A9KaeEkwF7EDQSru5lfPcOLm', '2024-06-28 12:52:15'),
(5, 'luism', '$2y$10$h5Vu.8wTqYHnKIcvchANNevwGlppgCR0HsTpnRCyPTS7KL7N.mNLS', '2024-06-28 13:25:14');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
