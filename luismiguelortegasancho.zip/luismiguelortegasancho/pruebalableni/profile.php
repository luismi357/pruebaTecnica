<?php
require 'config/config.php';
require 'templates/header.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

try {
    // Preparar la declaración
    $stmt = $mysqli->prepare("SELECT * FROM users WHERE id = ?");
    
    if (!$stmt) {
        throw new Exception("Error al preparar la declaracion: " . $mysqli->error);
    }

    // Vincular el parámetro
    $stmt->bind_param("i", $_SESSION['user_id']);

    // Ejecutar
    $stmt->execute();

    // Resultado
    $result = $stmt->get_result();
    
    if ($result) {
        $user = $result->fetch_assoc();
    } else {
        throw new Exception("Resultado fallido: " . $stmt->error);
    }

    // Sacar resultados y cerrar
    $stmt->free_result();
    $stmt->close();
    
} catch (Exception $e) {
    echo '<div class="alert alert-danger">' . $e->getMessage() . '</div>';
    exit;
}

// Cerrar la conexión
$mysqli->close();
?>
<!-- Seccion profile -->
<?php require('templates/headerLogo.php') ?>
                    <h2>Perfil</h2>
                        <p><strong>Usuario:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
                        <p><strong>Fecha de Regsitro:</strong> <?php echo htmlspecialchars($user['fecha_registro']); ?></p>
                        <a href="logout.php" class="btn btn-danger">Logout</a>
<?php require('templates/footerLogo.php') ?>
<?php require 'templates/footer.php'; ?>