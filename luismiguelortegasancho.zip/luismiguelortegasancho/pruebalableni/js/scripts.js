//Validacion formulario login a traves de JS
$(document).ready(function(){
$('#loginForm').on('submit', function(event) {
    event.preventDefault();
    const username = $('#username').val().trim();
    const password = $('#password').val().trim();
    let errors = [];

    if (errors.length > 0) {
        alert(errors.join('\n'));
    } else {
        $.ajax({
            url: 'login_action.php',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                username: username,
                password: password
            }),
            success: function(response) {
                $('#loading').hide(); // Ocultar el icono de carga
                const res = JSON.parse(response);
                if (res.success) {
                    window.location.href = 'profile.php';
                } else {
                    alert(res.error);
                }
            },
            error: function() {
                alert('Ha ocurrido un error. Por favor intentelo de nuevo.');
            }
        });
    }
    });
});
