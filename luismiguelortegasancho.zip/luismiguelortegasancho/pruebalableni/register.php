<?php
require 'config/config.php';
require 'templates/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $errors = [];

    if (empty($username) || empty($password) || empty($confirm_password)) {
        $errors[] = 'Todos los campos son requeridos';
    }

    if ($password !== $confirm_password) {
        $errors[] = 'Las passwords no coinciden';
    }

    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        try {
      
            $stmt = $mysqli->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            
            if (!$stmt) {
                throw new Exception("Error al preparar la declaracion: " . $mysqli->error);
            }

            
            $stmt->bind_param("ss", $username, $hashed_password);

            // Ejecutamos
            $stmt->execute();

            echo '<div class="alert alert-success">Registro completado!</div>';

            // Cerramos la declaracion
            $stmt->close();
        } catch (Exception $e) {
            if ($mysqli->errno == 1062) { // Código de error para clave duplicada
                echo '<div class="alert alert-danger">Ese nombre de usuario ya existe</div>';
            } else {
                echo '<div class="alert alert-danger">' . $e->getMessage() . '</div>';
            }
        }

        // Cerramos la conexion
        $mysqli->close();
    } else {
        foreach ($errors as $error) {
            echo '<div class="alert alert-danger">' . $error . '</div>';
        }
    }
}
?>
<!-- Seccion de registro -->
<section class="vh-100" style="background-color: #9A616D;">
<div class="container py-5 h-100">
  <div class="row d-flex justify-content-center align-items-center h-100">
    <div class="col col-xl-12">
      <div class="card" style="border-radius: 1rem;">
        <div class="row g-0">
          <div class="col-md-6 col-lg-4 d-none d-md-block">
            <img src="https://cdn.pixabay.com/photo/2023/07/30/11/39/girl-8158685_1280.jpg"
              alt="login form" class="img-fluid" style="border-radius: 1rem 0 0 1rem;" />
          </div>
          <div class="col-md-6 col-lg-6 d-flex align-items-center">
            <div class="card-body p-6 p-lg-7 text-black">
                <h2>Registro</h2>
                <form action="register.php" method="POST">
                    <div class="form-group">
                        <label for="username">Usuario:</label>
                        <input type="text" class="form-control" id="username" name="username">
                    </div>
                    <div class="form-group">
                        <label for="password">Contraseña:</label>
                        <input type="password" class="form-control" id="password" name="password">
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Confirmar contraseña:</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                    </div>
                    <button data-mdb-button-init data-mdb-ripple-init type="submit" class="btn btn-dark btn-lg btn-block">Registro</button><br>
                    <a href="login.php" data-mdb-button-init data-mdb-ripple-init class="btn btn-dark btn-lg btn-block">Volver al login</a>
                </form>
                </div>

            </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php require 'templates/footer.php'; ?>