<?php
require 'config/config.php';
require 'templates/header.php';

session_start();
?>
<!-- Seccion de login -->
        <?php require('templates/headerLogo.php') ?>
              <form id="loginForm" method="POST">

                  <div class="d-flex align-items-center mb-3 pb-1">
                    <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                    <span class="h1 fw-bold mb-0">Logo</span>
                  </div>

                  <div data-mdb-input-init class="form-outline mb-4">
                            <label for="username">Usuario:</label>
                            <input type="text" class="form-control" id="username" name="username">
                  </div>

                  <div data-mdb-input-init class="form-outline mb-4">
                            <label for="password">Password:</label>
                            <input type="password" class="form-control" id="password" name="password">
                  </div>

                  <div class="pt-1 mb-4">
                    <button data-mdb-button-init data-mdb-ripple-init class="btn btn-dark btn-lg btn-block" type="submit">Login</button>
                  </div>

                  <p class="mb-5 pb-lg-2" style="color: #393f81;">No tienes cuenta? <a href="register.php"
                      style="color: #393f81;">Registrate aqui</a></p>
                </form>

                  <!-- Cargar scripts al final del body para asegurar que el DOM esté listo -->
                  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
                  <script src="js/scripts.js"></script>

<?php require('templates/footerLogo.php') ?>          
<?php require 'templates/footer.php'; ?>