<?php
//Archivo de configuracion de conexion a bbdd Mysql
$host = 'localhost';
$db = 'pruebalableni';
$user = 'root';
$pass = '';

$mysqli = new mysqli($host, $user, $pass, $db);

if ($mysqli->connect_error) {
    die("Could not connect to the database $db : " . $mysqli->connect_error);
}


?>