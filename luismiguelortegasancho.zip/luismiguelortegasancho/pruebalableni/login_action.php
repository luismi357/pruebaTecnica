<?php
require 'config/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $data = json_decode(file_get_contents('php://input'), true);

    //Validamos los datos
    $username = trim($data['username'] ?? '');
    $password = trim($data['password'] ?? '');
    $errors = [];

    // Verificar que los campos no estén vacíos
    if (empty($username)) {
        $errors[] = 'Inserte usuario';
    }
    if (empty($password)) {
        $errors[] = 'Inserte Password';
    }

    // Si hay errores, devolverlos en la respuesta
    if (!empty($errors)) {
        echo json_encode(['error' => implode('\n', $errors)]);
        exit;
    }

    // Intentar obtener el usuario de la base de datos
    try {
        
        $stmt = $mysqli->prepare("SELECT * FROM users WHERE username = ?");
        if (!$stmt) {
            throw new Exception("Prepare statement failed: " . $mysqli->error);
        }

        // Vincular los parámetros
        $stmt->bind_param("s", $username);

        // Ejecutamos
        $stmt->execute();

        // Obtenemos el resultado
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        // Verificar si el usuario existe y la contraseña es correcta
        if ($user && password_verify($password, $user['password'])) {
            session_start();
            $_SESSION['user_id'] = $user['id'];
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['error' => 'Usuario o Password incorrecta']);
        }

        // Cerrar la declaración
        $stmt->close();
    } catch (Exception $e) {
        // Manejar errores de la base de datos
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
}
?>